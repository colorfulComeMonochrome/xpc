import redis
r = redis.Redis()